"""Review probes for swin2sr_x4_super_resolution_colab, torch-free (numpy + pillow).

P3  fetch the 27 pinned iNaturalist photos (digest-checked), rebuild the 24 pairs, and recompute the bicubic and
    nearest-neighbour baselines with the package's own metrics, to compare with the recorded Colab numbers; repeat
    the baselines for the activity's degradations (the model column needs torch and is not computed).
P4  BYOD reader in both modes on constructed inputs, plus the cell's upload branch with an empty upload.
"""
import io, json, sys, zipfile
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(repo / "src"))
import swin2sr_x4_super_resolution_pipeline as P
from swin2sr_x4_super_resolution_pipeline import samples as SM, metrics as M

res = {}
files = SM.fetch_photos(cache_dir=out / "photos")
files = files.get("files", files) if isinstance(files, dict) and "files" in files else files
if not isinstance(files, dict):
    files = {p.name: p.read_bytes() for p in (out / "photos").iterdir()}
pairs = SM.build_sample_pairs(files)
v = SM.validate_pairs(pairs)
b, n = M.bicubic_baseline(pairs), M.nearest_baseline(pairs)
pick = lambda d: {k: d.get(k) for k in ("psnr_y", "ssim_y", "psnr_rgb")} if isinstance(d, dict) else d
res["P3_default"] = {"pairs": len(pairs), "digest": SM.dataset_digest(pairs)[:16],
                     "bicubic": pick(b.get("mean", b)), "nearest": pick(n.get("mean", n)),
                     "colab_record": {"bicubic": {"psnr_y": 28.1487, "ssim_y": 0.7879, "psnr_rgb": 26.7813}, "nearest": {"psnr_y": 26.7177, "ssim_y": 0.7364, "psnr_rgb": 25.3368}, "digest": "db74c01e3c872fff"}}
act = {}
for kernel, q in (("bilinear", None), ("box", None), ("nearest", None), ("bicubic", 30)):
    pp = SM.build_sample_pairs(files, kernel=kernel, jpeg_quality=q)
    act[f"{kernel}{'' if q is None else '+jpeg' + str(q)}"] = pick(M.bicubic_baseline(pp).get("mean", M.bicubic_baseline(pp)))
res["P3_activity_bicubic_baseline"] = act

# P4 BYOD
rng = np.random.default_rng(0)
def png(w, h, mode="RGB"):
    im = Image.fromarray(rng.integers(0, 255, (h, w, 3), dtype=np.uint8))
    if mode != "RGB": im = im.convert(mode)
    bb = io.BytesIO(); im.save(bb, "PNG"); return bb.getvalue()
def put(name, data):
    p = out / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data); return p
cases = {
    "hr_ok_322x320": ("hr", put("hr_ok.png", png(322, 320))),
    "hr_too_small_30": ("hr", put("hr_small.png", png(30, 30))),
    "hr_too_big_1100": ("hr", put("hr_big.png", png(1100, 200))),
    "lr_ok_rgba_100": ("lr", put("lr_rgba.png", png(100, 90, "RGBA"))),
    "lr_too_big_300": ("lr", put("lr_big.png", png(300, 100))),
    "lr_tiny_6": ("lr", put("lr_tiny.png", png(6, 6))),
    "not_image": ("lr", put("notes.png", b"hello")),
}
zp = out / "mixed.zip"
with zipfile.ZipFile(zp, "w") as z:
    z.writestr("a.png", png(64, 64)); z.writestr("README.txt", b"x")
cases["zip_with_txt"] = ("lr", zp)
zp2 = out / "evil.zip"
with zipfile.ZipFile(zp2, "w") as z:
    z.writestr("../a.png", png(64, 64))
cases["zip_traversal"] = ("lr", zp2)
d = out / "dupdir"; (d / "x").mkdir(parents=True, exist_ok=True); (d / "y").mkdir(exist_ok=True)
(d / "x" / "img.png").write_bytes(png(64, 64)); (d / "y" / "img.png").write_bytes(png(64, 64))
cases["dir_duplicate_names"] = ("lr", d)
e = out / "emptydir"; e.mkdir(exist_ok=True)
cases["empty_dir_(cancelled_upload)"] = ("lr", e)
p4 = {}
for name, (mode, path) in cases.items():
    try:
        r = SM.prepare_byod(path, mode)
        recs = r.get("records") or r.get("inputs") or []
        p4[name] = {"accepted": True, "mode": mode, "n": len(recs), "keys": sorted(r)[:8], "preprocessing": r.get("preprocessing", r.get("cropped"))}
    except Exception as exc:
        p4[name] = {"accepted": False, "error": f"{type(exc).__name__}: {exc}"[:240]}
res["P4"] = p4
(out / "results.json").write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
